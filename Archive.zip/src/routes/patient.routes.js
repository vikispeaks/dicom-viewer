const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patient.controller');

router.get('/brief', patientController.getPatientBrief);
router.get('/clinical-notes', patientController.getClinicalNotes);
router.get('/problem-list', patientController.getProblemList);
router.get('/lab-results', patientController.getLabResults);
router.get('/allergies', patientController.getAllergies);

module.exports = router; 