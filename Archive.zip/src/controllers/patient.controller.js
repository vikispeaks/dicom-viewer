const fhirConfig = require('../config/fhir.config');
const patientService = require('../services/patient.service');

exports.getPatientBrief = async (req, res) => {
    try {
        const brief = await patientService.getPatientBrief(req.query.patientId);
        res.json(brief);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getClinicalNotes = async (req, res) => {
    try {
        const notes = await patientService.getClinicalNotes(req.query.patientId);
        res.json(notes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getProblemList = async (req, res) => {
    try {
        const problems = await patientService.getProblemList(req.query.patientId);
        res.json(problems);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getLabResults = async (req, res) => {
    try {
        const results = await patientService.getLabResults(req.query.patientId);
        res.json(results);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getAllergies = async (req, res) => {
    try {
        const allergies = await patientService.getAllergies(req.query.patientId);
        res.json(allergies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}; 